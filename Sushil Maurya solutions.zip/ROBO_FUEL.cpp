#include <iostream>
using namespace std;
#define MAX 9
int GASOLINE = 1;
int DIESEL = 2;
int GASOLINE_STATION = -1;
int DIESEL_STATION = -2;
int LEFT = 1;
int RIGHT = 2;
int N;
int cars[MAX];
bool done[MAX];
bool fueled[MAX];
int total;
int ans;

void startFueling(int position, int fuel, int station, int distance, int direction){
    if(total == N){
        if(ans==-1)
            ans = distance-1;
        else    
            ans = min(ans, distance-1);
    }
    if(ans!=-1 && distance > ans){
        return;
    }
    if(position == GASOLINE_STATION){
        startFueling(position+1, 2, GASOLINE_STATION, distance+1, LEFT);
    }else if(position == DIESEL_STATION){
        startFueling(position-1, 2, DIESEL_STATION, distance+1, RIGHT);
    }else if(cars[position] == GASOLINE){
        if(fuel == 0){
            startFueling(-1, fuel, GASOLINE_STATION, distance+position, LEFT);
            startFueling(N, fuel, GASOLINE_STATION, distance+N-position+1, RIGHT);
        }else{
            if(!fueled[position] && station == GASOLINE_STATION){
                fueled[position] = true;
                total+=1;
                startFueling(position+1, fuel-1, station, distance+1, LEFT);
                startFueling(position-1, fuel-1, station, distance+1, RIGHT);
                total-=1;
                fueled[position] = false;
            }
            if(fueled[position]){
                if(direction == LEFT){
                    startFueling(position+1, fuel, station, distance+1, LEFT);
                }else if(direction == RIGHT){
                    startFueling(position-1, fuel, station, distance+1, RIGHT);
                }
            }else{
                if(!(position+1==DIESEL_STATION && fuel == 2))
                    startFueling(position+1, fuel, station, distance+1, LEFT);
                if(!(position-1==GASOLINE_STATION && fuel == 2))
                    startFueling(position-1, fuel, station, distance+1, RIGHT);
            }
        }
    }else if(cars[position] == DIESEL){
        if(fuel == 0){
            startFueling(-1, fuel, DIESEL_STATION, distance+position, LEFT);
            startFueling(N, fuel, DIESEL_STATION, distance+N-position+1, RIGHT);
        }else{
            if(!fueled[position] && station == DIESEL_STATION){
                fueled[position] = true;
                total+=1;
                startFueling(position+1, fuel-1, station, distance+1, LEFT);
                startFueling(position-1, fuel-1, station, distance+1, RIGHT);
                total-=1;
                fueled[position] = false;
            }
            if(fueled[position]){
                if(direction == LEFT){
                    startFueling(position+1, fuel, station, distance+1, LEFT);
                }else if(direction == RIGHT){
                    startFueling(position-1, fuel, station, distance+1, RIGHT);
                }
            }else{
                if(!(position+1==DIESEL_STATION && fuel == 2))
                    startFueling(position+1, fuel, station, distance+1, LEFT);
                if(!(position-1==GASOLINE_STATION && fuel == 2))
                    startFueling(position-1, fuel, station, distance+1, RIGHT);
            }
        }
    }
}

bool compatible(int station, int position){
    return (station==GASOLINE_STATION && cars[position] == GASOLINE)
            ||
            (station==DIESEL_STATION && cars[position] == DIESEL);
}

void move(int position, int fuel, int station, int distance, int direction){
    if(total == N){
        if(ans==-1)
            ans = distance-1;
        else    
            ans = min(ans, distance-1);
        //cout<<"Reached End:"<<distance<<endl;
    }
    if(ans!=-1 && ans<=distance){
        return;
    }
    if(position == GASOLINE_STATION){
        //cout<<"At"<<position<<" FILL G"<<endl;
        move(position+1, 2, GASOLINE_STATION, distance+1, LEFT);
    }else if(position == DIESEL_STATION){
        //cout<<"At"<<position<<" Fill_D\n";
        move(position-1, 2, DIESEL_STATION, distance+1, RIGHT);
    }else if(fuel == 0){
        //cout<<"Fuel Over:"<<"At"<<position<<" "<<"Move"<<endl;;
        move(-1, fuel, station, distance+position, RIGHT);
        move(N, fuel, station, distance+N-position, LEFT);
    }else{
        //Cars
        if(!fueled[position] && compatible(station, position)){
            //cout<<"At"<<position<<" Fill"<<distance<<endl;
            fueled[position] = true;
            total+=1;
            if(direction == LEFT){
                move(position+1, fuel-1, station, distance+1, LEFT);
            }else if(direction == RIGHT){
                move(position-1, fuel-1, station, distance+1, RIGHT);
            }
            total-=1;
            fueled[position] = false;
        }
        //cout<<"At"<<position<<" Move without fill"<<endl;
        if(direction == LEFT){
            move(position+1, fuel, station, distance+1, LEFT);
        }else if(direction == RIGHT){
            move(position-1, fuel, station, distance+1, RIGHT);
        }
    }
}

int solve(){
    cin>>N;
    DIESEL_STATION = N;
    ans = -1;
    total = 0;
    for(int i=0;i<N;i++){
        cin>>cars[i];
        done[i] = false;
        fueled[i] = false;
    }
    move(-1, 0, GASOLINE_STATION, 0, LEFT);
    cout<<ans<<endl;
}

int main(){
    int T;
    cin>>T;
    while(T--){
        solve();
    }
    return 0;
}