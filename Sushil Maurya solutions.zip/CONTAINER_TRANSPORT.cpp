#include <iostream>
using namespace std;
#define MAX 9
#define LEFT 0
#define RIGHT 1
int N;
int containers[MAX], containers_side[MAX];
int minPrice;

//can use bitmaskdp
void best(int side, int transported, int price){
    cout<<side<<","<<transported<<","<<price<<endl;
    for(int i=0;i<N; i++){
        cout<<containers_side[i]<<" ";
    }
        cout<<endl;
    if(side == LEFT){
        if(transported == N-1){
            for(int i=0; i<N; i++){
                if(containers_side[i] == side){
                    price += containers[i];
                    break;
                }
            }
            if(price < minPrice){
                minPrice = price;
            }
            return;
        }
        for(int i=N-1;i>=0;i--){
            if(containers_side[i] == side){
                containers_side[i] = !containers_side[i];
                for(int j=i-1; j>=0; j--){
                    //chosen i, j, 
                    if(containers_side[j] == side){
                        containers_side[j] = !containers_side[j];
                        best(!side, transported+2, price+max(containers[i], containers[j]));
                        containers_side[j] = !containers_side[j];
                    }
                }
                containers_side[i] = !containers_side[i];
            }
        }
    }else{
        if(transported == N){
            if(price < minPrice){
                minPrice = price;
            }
            return;
        }
        //choose min from this side and go using that or pay and go
        int m = -1;
        for(int i = 0; i<N; i++){
            if(containers_side[i] == side){
                if(m==-1 || containers[i] < containers[m])
                    m = i;
            }
        }
        if(containers[m]<1000){
            containers_side[m] = !containers_side[m];
            best(!side, transported-1, price+containers[m]);
            containers_side[m] = !containers_side[m];
        }else{
            best(!side, transported, price+1000);
        }
    }
}

int solve(){
    cin>>N;
    for(int i=0;i<N;i++){
        cin>>containers[i];
        containers_side[i] = LEFT;
    }
    minPrice = 0xFFFFF;
    best(LEFT, 0, 0);
    cout<<minPrice<<endl;
}

int main(){
    int T;
    cin>>T;
    for(int t=1; t<=T; t++){
        solve();
    }
    return 0;
}