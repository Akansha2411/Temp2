#include <iostream>
using namespace std;
#define MAX 1000
int M[MAX], S[MAX], EE[MAX];
int D, E;
int ansm, anss;
int dp[MAX][MAX];

void run(int start, int d, int e, int m, int s){
    m = m + s/60;
    s = s%60;
    if(d == 0){
        if(e<=E){
            if(ansm==-1 || ansm>m || (ansm == m && anss>s)){
                ansm = m;
                anss = s;
            }
        }
        return;
    }
    if(e>E || (ansm!=-1 && ansm<m))// || dp[d][e])
        return;
    //dp[d][e] = true;
    for(int i=start; i<5; i++){
        run(i, d-1, e+EE[i], m+M[i], s+S[i]);
    }
}

int solve(){
    cin>>E>>D;
    for(int i=0; i<5; i++){
        //cout<<i<<endl;
        cin>>M[i]>>S[i]>>EE[i];
    }
    ansm=-1;
    anss=-1;
    for(int i=0;i<MAX;i++)
        for(int j=0;j<MAX;j++)
            dp[i][j] = false;
    run(0, D, 0, 0, 0);
    cout<<ansm<<" "<<anss<<endl;
}

int main(){
    solve();
    return 0;
}

