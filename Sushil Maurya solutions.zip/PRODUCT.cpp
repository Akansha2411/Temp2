#include <iostream>
#include <cstdio>
#pragma GCC optimize("-Ofast")
using namespace std;
#define MAX 9
int n_cpu, n_mem, n_board, price_cpu, price_mem; 
int N;
int m_cpu[MAX], m_mem[MAX], m_board[MAX], m_price[MAX];
int finalPrice;
int usedModels[MAX];
int usedPtr;

void print(){
    for(int i=0;i<=usedPtr;i++){
        cout<<usedModels[i]<<" ";
    }
}

void sell(int models, int cpu, int mem, int board, int price){
    //cout<<"Left: "<<cpu<<" "<<mem<<" "<<board<<endl;
    if(models <= 3){
        print();
        cout<<endl<<cpu<<" "<<mem<<" "<<endl;
        finalPrice = max(price + cpu*price_cpu + mem*price_mem, finalPrice);
    }
    cout<<finalPrice<<" "<<endl<<endl;
    if(models==0){
        return;
    }
    for(int i = 0; i<N; i++){
        if(m_cpu[i]<=cpu && m_mem[i]<=mem && m_board[i]<=board){
            //cout<<m_cpu[i]<<" "<<m_mem[i]<<" "<<m_board[i]<<endl;
            usedModels[++usedPtr] = i;
            sell(models-1, cpu-m_cpu[i], mem-m_mem[i], board-m_board[i], price+m_price[i]);
            usedPtr--;
        }
    }
}

void solve(){
    cin >> n_cpu >> n_mem >> n_board >> price_cpu >> price_mem;
    cin>>N;
    for(int i=0; i<N; i++){
        cin>>m_cpu[i]>>m_mem[i]>>m_board[i]>>m_price[i];
    }
    finalPrice=-1;
    usedPtr = -1;
    sell(3, n_cpu, n_mem, n_board, 0);
    cout<<finalPrice<<endl;
}

int main(){
    int T;
    freopen("input_product.txt", "r", stdin);
    cin>>T;
    for(int t=1; t<=T; t++){
        solve();
    }
    return 0;
}