#include <iostream>
using namespace std;
#define MAX 100
bool visited[MAX][MAX];
int mat[MAX][MAX];
//even is even
int directionX[2][6] = {{-1, -1, -1, 0, 0, 1}, 
                        {-1, 0, 0, 1, 1, 1}};
int directionY[2][6] = {{-1, 0, 1, -1, 1, 0},
                        {0, -1, 1, -1, 0, 1}};
int M, N;

//TODO: Clean the code

bool inRange(int x, int y){
    return (x>=0 && x<N && y>=0 && y<M);
}

//if visited then also return -1 // all can be removed
int getUp(int x, int y){
    if(!inRange(x-1, y) || visited[x-1][y])
        return -1;
    return mat[x-1][y];
}
int getDown(int x, int y){
    if(!inRange(x+1, y) || visited[x+1][y])
        return -1;
    return mat[x+1][y];
}
int getLeft(int x, int y){
    if(!inRange(x, y-1) || visited[x][y-1])
        return -1;
    return mat[x][y-1];
}
int getRight(int x, int y){
    if(!inRange(x, y+1) || visited[x][y+1])
        return -1;
    return mat[x][y+1];
}
int getUpRight(int x, int y){
    if(!inRange(x-1, y+1) || visited[x-1][y+1])
        return -1;
    return mat[x-1][y+1];
}
int getDownRight(int x, int y){
    if(!inRange(x+1, y+1) || visited[x+1][y+1])
        return -1;
    return mat[x+1][y+1];
}
int getUpLeft(int x, int y){
    if(!inRange(x-1, y-1) || visited[x-1][y-1])
        return -1;
    return mat[x-1][y-1];
}
int getDownLeft(int x, int y){
    if(!inRange(x+1, y-1) || visited[x+1][y-1])
        return -1;
    return mat[x+1][y-1];
}
//remove this function
void getMaxNeighbour(int x, int y, int &a, int &b, int &c){
    int ans[6];
    ans[0] = getUp(x, y);
    ans[1] = getDown(x, y);
    ans[2] = getLeft(x, y);
    ans[3] = getRight(x, y);
    if(y%2==0){
        ans[4] = getUpLeft(x, y);
        ans[5] = getUpRight(x, y);
    }else{
        ans[4] = getDownLeft(x, y);
        ans[5] = getDownRight(x, y);
    }
    a = b = c = -1;
    for(int i=0;i<6;i++){
        if(ans[i]>a){
            c = b;
            b = a;
            a = ans[i];
        }else if(ans[i]>b){
            c = b;
            b = ans[i];
        }else if(ans[i]>c){
            c = ans[i];
        }
    }
}
//reset

int dfs(int x, int y, int depth){
    int a, b, c, ans = -1, tx, ty, tm = -1;
    if(depth == 1)
        return mat[x][y];
    //remove maxFun
    if(depth == 2){
        //check for visited
        getMaxNeighbour(x, y, a, b, c);
        if(a!=-1)
            return mat[x][y] + a;
        else    
            return -1;
    }
    if(depth == 3){
        getMaxNeighbour(x, y, a, b, c);
        if(a!=-1 && b!=-1)
            ans = mat[x][y] + a + b;
        tm = -1;
        //methods to traverse using loop 
        for(int i=0;i<6;i++){
            tx = x+directionX[y%2][i];
            ty = y+directionY[y%2][i];
            if(inRange(tx, ty) && !visited[tx][ty]){
                visited[tx][ty] = true;
                if(tm == -1) tm = dfs(tx, ty, 2);
                else tm = max(tm, dfs(tx, ty, 2));
                visited[tx][ty] = false;
            }
        }
        if(tm != -1)
            ans = max(ans, tm+mat[x][y]);
        return ans;
    }
    //can use loops to find pairs
    if(depth == 4){
        for(int i=0, cx, cy;i<6;i++){
            cx = x+directionX[y%2][i];
            cy = y+directionY[y%2][i];
            tm = -1;
            if(inRange(cx, cy) && !visited[cx][cy]){
                visited[cx][cy] = true;
                tm = -1;
                for(int j=0;j<6;j++){
                    if(i == j)
                        continue;
                    tx = cx+directionX[cy%2][j];
                    ty = cy+directionY[cy%2][j];
                    if(inRange(tx, ty) && !visited[tx][ty]){
                        visited[tx][ty] = true;
                        if(tm == -1) tm = dfs(tx, ty, 2);
                        else tm = max(tm, dfs(tx, ty, 2));
                        visited[tx][ty] = false;
                    }
                }
                visited[cx][cy] = false;
                if(tm != -1)
                    ans = max(ans, tm+mat[cx][cy]+mat[x][y]);
            }
        }
        tm = -1;
        //methods to traverse using 
        for(int i=0;i<6;i++){
            tx = x+directionX[y%2][i];
            ty = y+directionY[y%2][i];
            if(inRange(tx, ty) && !visited[tx][ty]){
                visited[tx][ty] = true;
                if(tm == -1) tm = dfs(tx, ty, 3);
                else tm = max(tm, dfs(tx, ty, 3));
                visited[tx][ty] = false;
            }
        }
        if(tm != -1)
            ans = max(ans, tm+mat[x][y]);
        return ans;
    }
}

int maxPopulation = -1;
//Classic Double Repeating DFS
//Can be further memoized(use src, curr, and depth)
void doubleDfs(int x, int y, int depth, int population){
    if(depth == 4){
        maxPopulation = max(maxPopulation, population);
        return;
    }
    for(int i=0, cx, cy; i<6; i++){
        cx = x+directionX[y%2][i];
        cy = y+directionY[y%2][i];
        if(inRange(cx, cy) && !visited[cx][cy]){
            visited[cx][cy] = true;
            doubleDfs(x, y, depth+1, population+mat[cx][cy]);
            doubleDfs(cx, cy, depth+1, population+mat[cx][cy]);
            visited[cx][cy] = false;
        }
    }
}

int solve(){
    cin>>N>>M;
    for(int i=0;i<N;i++){
        for(int j=0;j<M;j++){
            cin>>mat[i][j];
            visited[i][j] = false;
        }
    }
    int ans = -1;
    for(int i=0;i<N; i++){
        for(int j=0, t;j<M;j++){
            /**
            visited[i][j] = true;
            t = dfs(i, j, 4);
            //cout<<t<<endl;
            ans = max(ans, t);
            visited[i][j] = false;
            */
            visited[i][j] = true;
            doubleDfs(i, j, 1, mat[i][j]);
            visited[i][j] = false;
        }
    }
    //cout<<ans<<endl;
    cout<<maxPopulation<<endl;
}

int main(){
    int T;
    cin>>T;
    for(int t=1; t<=T; t++){
        solve();
    }
    return 0;
}