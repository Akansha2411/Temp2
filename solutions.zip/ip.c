#include<stdio.h>
#define K 4
#define N 3
int no;
int num[6];
int pel_even[12];
int pel_odd[12];
int ans = 0;
int used[6] = { 0 };
int stack[K];
int allreadySelected[5] = { 0 };

void ip_calculate(int arr[], int size, int selectCount, int total)
{
	if (selectCount == K)
	{
		int index;
		int ip_sum, i, j, k, l;
		int sum1 = 0;
		for (k = 0; k < K; k++) {
			sum1 += stack[k];
		}
			if (sum1 == size) {
			for (i = 0, j = 0; i < K; i++) {
				if (stack[i] == 2) {
					if (!arr[j]) {
						return;
					}
				}
				if (stack[i] == 3) {
					if (!arr[j]) {
						return;
					}
					if (((100 * arr[j]) + (10 * arr[j + 1]) + arr[j + 2]) > 255) {
						return;
					}
				}
				j += stack[i];
			}
			ans++;
		}
		if (selectCount == K) {
			return;
		}
	}
	for (int i = 1; i <= N; i++)
	{
		stack[selectCount] = i;
		allreadySelected[i] = 1;
		ip_calculate(arr, size, selectCount + 1, total + i);
		allreadySelected[i] = 0;
	}
}
int generate_pelendrum(int count, int total) {
	int i, j;
	if (total == no) {
		for (i = 0; i < no; i++) {
			pel_even[no + i] = pel_even[no - 1 - i];
			if (no - 2 - i >= 0)
				pel_odd[no + i] = pel_even[no - 2 - i];
		}
		ip_calculate(pel_even, 2 * no, 0, 0);
		ip_calculate(pel_odd, (2 * no) - 1, 0, 0);
	}
	for (i = 0; i < no; i++) {
		if (used[i] == 0) {
			used[i] = 1;
			pel_even[total] = num[i];
			pel_odd[total] = num[i];
			generate_pelendrum(i, total + 1);
			used[i] = 0;
		}
	}
}
main() {
	int testcase, T;
	int i;
	scanf("%d", &testcase);

	for (T = 0; T < testcase; T++) {
		scanf("%d", &no);
		for (i = 0; i < no; i++) {
			scanf("%d", &num[i]);
		}
		generate_pelendrum(0, 0);
		printf("#%d %d\n", T + 1, ans);
		ans = 0;
	}
}