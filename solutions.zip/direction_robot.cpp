#include<iostream>
using namespace std;
bool mat[100][100];
bool vis[100][100];

void func(int rw,int cw,bool mat[][100],bool vis[][100],int i,int j,int x,int y,int s,int &res,int l,int r,int u,int d)
{
    //cout<<"s "<<s<<endl;
    int flag=0;
    for(int l=1;l<=rw;l++)
        {
        for(int k=1;k<=cw;k++)
            cout<<vis[l][k];
        cout<<endl;
        }
    cout<<endl;    
    //cout<<i<<" "<<j<<" "<<endl;    
    if(i==x && j==y)
    {
        if(s<res)
            res=s;
        return;
    }    
    if(i>rw||j>cw||i==0||j==0)
        return;
        
    if(i<rw && mat[i+1][j]!=1 && !vis[i+1][j])
        {
            if(d==0)
            {
                flag=1;
                d=1;
               
                s+=1;
            }    
            vis[i+1][j]=1;
            func(rw,cw,mat,vis,i+1,j,x,y,s,res,0,0,0,d);
            //cout<<"ret s "<<s<<endl;
            vis[i+1][j]=0;
            if(flag==1)
            {
                flag=0;
                s--;
                d=0;
            }
            //cout<<i<<" "<<j<<" "<<endl;
            //cout<<"down s "<<s<<endl;
        }  
        
    if(i>1 && mat[i-1][j]!=1 && !vis[i-1][j] )
        {
            if(u==0)
            {
                flag=1;
                u=1;
                s+=1;
            }    
            vis[i-1][j]=1;
            func(rw,cw,mat,vis,i-1,j,x,y,s,res,0,0,u,0);
            //cout<<"ret s "<<s<<endl;
            vis[i-1][j]=0;
            if(flag==1)
            {
                flag=0;
                u=0;
                s--;
            }
            //cout<<i<<" "<<j<<" "<<endl;
            //cout<<"up s "<<s<<endl;
        }  
        
    if(j>1 && mat[i][j-1]!=1 && !vis[i][j-1] )
       {
           if(l==0)
            {
                flag=1;
                l=1;
                s+=1;
            }    
            vis[i][j-1]=1;
		    func(rw,cw,mat,vis,i,j-1,x,y,s,res,l,0,0,0);
		    //cout<<"ret s "<<s<<endl;
		    vis[i][j-1]=0;
		    if(flag==1)
            {
                flag=0;
                l=0;
                s--;
            }
            //cout<<i<<" "<<j<<" "<<endl;
            //cout<<"left s "<<s<<endl;
       }    
       
    if(j<cw && mat[i][j+1]!=1 && !vis[i][j+1] )
       {
           if(r==0)
            {
                flag=1;
                r=1;
                s+=1;
            }    
            vis[i][j+1]=1;
		    func(rw,cw,mat,vis,i,j+1,x,y,s,res,0,r,0,0);
		    //cout<<"ret s "<<s<<endl;
		    vis[i][j+1]=0;
		    if(flag==1)
            {
                flag=0;
                r=1;
                s--;
            }
            //cout<<i<<" "<<j<<" "<<endl;
            //cout<<"right s "<<s<<endl;
       }
       
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int rw,cw;
		cin>>rw>>cw;
		int s=-1;
		int l=0,r=0,u=0,d=0;
		int res=1000;
		int x,y,x1,y1;
		cin>>x>>y>>x1>>y1;
		
		for(int i=1;i<=rw;i++)
			for(int j=1;j<=cw;j++)
				cin>>mat[i][j];
				
		for(int i=1;i<=rw;i++)
			for(int j=1;j<=cw;j++)
				vis[i][j]=0;
				
	    vis[x][y]=1;
	    
		func(rw,cw,mat,vis,x,y,x1,y1,s,res,l,r,u,d);
		cout<<res<<endl;
	}
}