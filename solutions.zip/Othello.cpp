#include<iostream>
using namespace std;
int seek(int a[],int n)
{
    int i;
    for(i=0;i<n;i++)
        if(a[i]==0)
            return i;
    return -1;        
}
void change(int n,int a[],int p,int pos)
{
    a[pos]=p;
    int flag=0;
    int v,i;
    for(i=pos+1;i<n&&flag==0;i++)
    {
        if(a[i]==0)
            break;
        if(a[i]==p||i==n-1)
        {
            flag=1;
            v=i;
        }
    }    
    for(int j=v;j>=pos&&flag==1;j--)
        a[j]=p;
    flag=0;    
    for(i=pos-1;i>=0&&flag==0;i--)
    {
        if(a[i]==0)
            break;
        if(a[i]==p||i==0)
        {
            flag=1;
            v=i;
        }
    }    
    for(int j=v;j<=pos&&flag==1;j++)
        a[j]=p;    
        
    for(int i=0;i<n;i++)
        cout<<a[i];
    cout<<endl;    
}
void func(int c,int n,int arr[],int &max)
{

    if(c==0)
    {
        int x=0;
        for(int i=0;i<n;i++)
            if(arr[i]==1)
                x++;
        if(x>max)
        {    max=x;
            cout<<" max "<<max<<endl;
        }    
        return;    
    }
    else
    {
        int ox[n];
        for(int i=0;i<n;i++)
            ox[i]=arr[i];
        for(int i=0;i<n;i++)    
        {   
            if(arr[i]!=0)
                continue;
            change(n,arr,1,i);
            int place=seek(arr,n);
            cout<<place<<endl;
            if(place!=-1)
                change(n,arr,2,place);
            func(c-1,n,arr,max);
            for(int i=0;i<n;i++)
                arr[i]=ox[i];
        }    
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,max=0;
        cin>>n;
        int arr[n];
        for(int i=0;i<n;i++)
            cin>>arr[i];
            
        func(3,n,arr,max);
        cout<<max<<endl;
    }
    return 0;
}