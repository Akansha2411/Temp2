#include<iostream>
using namespace std;

void sort(double arr[],int n)
{
    int i, j, id;
    for (i = 0; i < n-1; i++)
    {
        id = i;
        for (j = i+1; j < n; j++)
            if (arr[j] < arr[id])
                id = j;
        swap(arr[id], arr[i]);
    }
}
int dp(int t1[],int t2[],int a,int b)
{
	int s=0,mi,mx;
	mi=min(a,b);
	
	int ox[mx];
	for(int i=0;i<mi;i++)
		for(int j=0;j<mx;j++)
		{
			
		}	
	return s;
}
main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int a,b;
		cin>>a>>b;
		double t1[a];
		double t2[b];
		for(int i=0;i<a;i++)
			cin>>t1[i];
		for(int i=0;i<b;i++)
			cin>>t2[i];
		sort(t1,a);
		sort(t2,b);
		/*for(int i=0;i<a;i++)
			cout<<t1[i];
		for(int i=0;i<b;i++)
			cout<<t2[i];*/
		int s=dp(t1,t2,a,b);
		cout<<s<<endl;
	}
}