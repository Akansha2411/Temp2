#include<iostream>
using namespace std;
int min(int a, int b)
{
	return a < b ? a : b;
}
void func(int i, int arr[10], int n, int cp, int cd, int sum, int pc, int dc, int &ans, int dir, int ndir)
{
	if (pc == 0 && dc == 0)
	{
		//cout<<sum<<endl;
		ans = min(ans, sum);
		return;
	}
	if (i == n)
	{
		if (cp == 2 || cd == 2)
			return;
		func(n - 1, arr, n, 0, 2, sum + 1, pc, dc, ans, -1, 1);
		return;
	}
	else if (i == 0)
	{
		if (cp == 2 || cd == 2)
			return;
		func(1, arr, n, 2, 0, sum + 1, pc, dc, ans, 1, 1);
		return;
	}
	if (cp == 0 && cd == 0)
	{
		if (pc != 0)
			func(0, arr, n, 0, 0, sum + i, pc, dc, ans, 1, ndir);
		if (dc != 0)
			func(n, arr, n, 0, 0, sum + n - i, pc, dc, ans, -1, ndir);
		return;
	}
	if (cp > 0 && arr[i] == 1)
	{
		func(i + dir, arr, n, cp, cd, sum + 1, pc, dc, ans, dir, ndir);
		arr[i] = -1;
		func(i + dir, arr, n, cp - 1, cd, sum + 1, pc - 1, dc, ans, dir, ndir);
		if (ndir>0)
			func(i - dir, arr, n, cp - 1, cd, sum + 1, pc - 1, dc, ans, -1 * dir, ndir - 1);
		arr[i] = 1;
	}
	else if ((cp > 0 && arr[i] != 1))
	{
		func(i + dir, arr, n, cp, cd, sum + 1, pc, dc, ans, dir, ndir);
	}
	else if (pc == 0 && cp>0)
	{
		func(n, arr, n, cp, cd, sum + n - i, pc, dc, ans, dir, ndir);
	}
	else if (dc == 0 && cd>0)
	{
		func(0, arr, n, cp, cd, sum + i, pc, dc, ans, dir, ndir);
	}
	else if (cd > 0 && arr[i] == 2)
	{
		func(i + dir, arr, n, cp, cd, sum + 1, pc, dc, ans, dir, ndir);
		arr[i] = -1;
		func(i + dir, arr, n, cp, cd - 1, sum + 1, pc, dc - 1, ans, dir, ndir);
		if (ndir>0)
			func(i - dir, arr, n, cp, cd - 1, sum + 1, pc, dc - 1, ans, -1 * dir, ndir - 1);
		arr[i] = 2;
	}
	else if ((cd > 0 && arr[i] != 2))
	{
		func(i + dir, arr, n, cp, cd, sum + 1, pc, dc, ans, dir, ndir);
	}
}
int main()
{
	int t;
	cin >> t;
	while (t--)
	{
		int n;
		cin >> n;
		int arr[10] = { 0 }, pc = 0, dc = 0;
		for (int i = 1; i <= n; i++)
		{
			cin >> arr[i];
			if (arr[i] == 1)
				pc++;
			else
				dc++;
		}
		int ans = 99999999;
		func(0, arr, n + 1, 1, 0, 0, pc, dc, ans, 1, 1);
		cout << ans - 1 << endl;
	}
}