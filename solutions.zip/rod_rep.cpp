#include<iostream>
using namespace std;
int vis[100000]={0};
int h[100000]={0};

void func(int i,int arr[],int count,int n,int k,int c,int &min,int start,int end)
{
    cout<<"Hi"<<endl;
    int x=0;
    for(int f=0;f<=end+2;f++)
    {
        if(h[f]==2 && vis[f]==1)
          x++;  
         //cout<<x<<endl; 
    }
    
    if(i==n-1 && count==x)
    {
        /*for(int j=start;j<=end+2;j++)
            cout<<vis[j];
        cout<<endl;*/
        
        for(int i=start;i<=end+2;i++)
            if(vis[i]==1)
                c++;
        //cout<<"count "<<c<<endl;        
        if(c<min)
            min=c;
        return;    
    }
    else if(i==n-1)
        return;
    else    
    {
        int ox[100000];
        for(int i=0;i<=100000;i++)
            ox[i]=vis[i];
        for(int j=arr[i];j<k+arr[i] && j<=end+2 ;j++)
                    vis[j]=1;
                    
                    
        func(i+1,arr,count,n,k,c,min,start,end);
        
        for(int i=0;i<=100000;i++)
            vis[i]=ox[i];
            
        func(i+1,arr,count,n,k,c,min,start,end);  
    }
}
void s(int arr[], int n)
{
	int i, j, min;
	for(i = 0; i < n; i++)
	{
		min = i;
		for(j = i + 1; j < n; j++)
		{
			if(arr[j] < arr[min])
				min = j;
		}
		int t;
		t = arr[i];
		arr[i] = arr[min];
		arr[min] = t;
	}
}
int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n,min=1000,k;
		cin >> n>>k;
		int a[10];
		for(int i = 0; i < n; i++)
			cin >> a[i];
		s(a, n);
		for(int i=0;i<n;i++)
		    {
		        h[a[i]]=2;
		    }
		/*for(int i=0;i<=a[n-1];i++)
            cout<<vis[i];  
            cout<<endl;*/
		/*for(int i = 0; i < n; i++)
			cout << a[i] << " ";
		cout << endl;*/
		int i=a[0];
		int j=0;
	    int loc[100000];
	    
	    while(i<=a[n-1])
	    {
	        loc[j]=i;
	        cout<<loc[j]<<" ";
	        j++;
	        i++;
	    }
	    cout<<endl;
		/*cout<<a[0]<<a[n-1]<<endl;*/
		cout<<"yes"<<endl;
		func(0,loc,n,j,k,0,min,a[0],a[n-1]);
		cout<<min<<endl;
	}
	return 0;
}