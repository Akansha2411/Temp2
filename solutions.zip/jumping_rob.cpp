#include<iostream>
using namespace std;
bool find(int x[],int n)
{
	for(int i=0;i<n;i++)
		if(x[i]==2)
			return 1;
	return 0;	
}
int jump(int n,int arr[],int c,int j)
{
	if(find(arr,n)==0)
		return c;
	int cp[n];
	for(int i=0;i<n;i++)
		cp[i]=arr[i];
	for(int i=n-1;i>-1;i--)
		if(cp[i]==2)
		{
			if(i+j>=n)
			{
				cp[i]=1;
				c++;
			}
			else
			{
				if(cp[i+j]==1)
				{
					cp[i+j]=2;
					cp[i]=1;
				}
				else
				{
					cp[i+j]=1;
					cp[i]=1;
				}					
			}
		}
	int m=jump(n,cp,c,1);
	int r=jump(n,cp,c,2);
	int max;
	if(m>r)
			max=m;
		else
			max=r;
	return max;	
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		int a[n];
		for(int i=0;i<n;i++)
			cin>>a[i];
		int m=jump(n,a,0,1);
		int r=jump(n,a,0,2);
		int max;
		if(m>r)
			max=m;
		else
			max=r;
		cout<<max<<endl;
	}
	return 0;
}