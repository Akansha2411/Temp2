#include<iostream>
using namespace std;

bool palindrome(string s,int i,int j)
{
	while(i<=j)
	{
		if(s[i]!=s[j])
			return false;
		i++;j--;
	}
	return true;
}

int part(string s, int i,int j)
{
	if(i==j)
		return 0;
	else if(palindrome(s,i,j)==true)
		return 0;
	else
	{
		int min=9999999;
		for(int k=i;k<j;k++)
		{
			int count = part(s,i,k)+1+part(s,k+1,j);
			min=min<count?min:count;
		}
		return min;
	}
}

int main()
{
	int t;
	cin>>t;
	for(int T=1;T<=t;T++)
	{
		string s;
		cin>>s;
		int ans=s.length()-1;
		cout<<part(s,0,s.length()-1)<<endl;
	}
}