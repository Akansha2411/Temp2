#include<iostream>
using namespace std;
int dp[100][100];
bool v[100][100];

int func(string s,int n)
{
	for(int i=0;i<n;i++)
	{
		dp[i][i]=0;
		v[i][i]=1;
	}
	int j;
	for(int k=2;k<=n;k++)
	{
		for(int i=0;i<=n-k+1;i++)
		{
			j=i+k-1;
			if(k==2)
				v[i][j]=(s[i]==s[j]);
			else
				v[i][j]=(s[i]==s[j]) && v[i+1][j-1];
			
			if(v[i][j]==1)
				dp[i][j]=0;
			else
			{
				dp[i][j]=9999999;
				for(int l=i;l<=j-i;l++)
					dp[i][j]=min(dp[i][j],dp[i][l]+dp[l+1][j]+1);
			}
		}
	}
	return dp[0][n-1];
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		string s;
		cin>>s;
		int n;
		n=s.length();
		int m;
		m=func(s,n);
		cout<<m<<endl;
	}
}