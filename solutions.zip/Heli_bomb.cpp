#define _CRT_SECURE_NO_WARNINGS
#pragma GCC optimize("-Ofast")
#include <stdio.h>
int map[16][13];
int cmap[16][13];
int N, W, H;
int Answer;
int dx[] = { 0, -1, 0, 1 };
int dy[] = { -1, 0, 1, 0 };

bool issafe(int m, int n){
	if (m >= 0 && m<H && n >= 0 && n<W) return true;
	else return false;
}

void bomb(int i, int j){
	int temp = map[i][j];
	map[i][j] = -1;

	for (int k = 1; k<temp; k++){  // blasting in four directions based on the block value
		for (int x = 0; x<4; x++){
			int m = i + k*dx[x];
			int n = j + k*dy[x];
			if (issafe(m, n)) bomb(m, n);
		}
	}
}

void reconstruct()
{
	for (int j = 0; j<W; j++)
	{
		for (int i = 0; i<H; i++)
		{
			if (map[i][j] == -1)
			{
				int temp = i;
				for (int k = i - 1; k >= 0; k--)
				{	// moving down the blocks after blast if empty
					map[i--][j] = map[k][j];
					map[k][j] = 0;
				}
				i = temp;
			}
		}
	}

	for (int i = 0; i<H; i++)
	for (int j = 0; j<W; j++)
	if (map[i][j] == -1)  map[i][j] = 0;
}

void blast(int i, int j, int k, int l){
	if (i != -1){
		for (int a = 0; a<H; a++){
			if (map[a][i] != 0){  // dropping bomb on the first numbered(1-9) block in that column
				bomb(a, i);       // blasting the blocks 
				reconstruct();    // reconstructing the array after the blasts
				break;
			}
		}
	}
	if (j != -1){
		for (int a = 0; a<H; a++){
			if (map[a][j] != 0){
				bomb(a, j);
				reconstruct();
				break;
			}
		}
	}
	if (k != -1){
		for (int a = 0; a<H; a++){
			if (map[a][k] != 0){
				bomb(a, k);
				reconstruct();
				break;
			}
		}
	}
	if (l != -1){
		for (int a = 0; a<H; a++){
			if (map[a][l] != 0){
				bomb(a, l);
				reconstruct();
				break;
			}
		}
	}
}

void calculateRemaining(){
	int count = 0;
	for (int i = 0; i < H; i++)
		for (int j = 0; j < W; j++)
			if (map[i][j] != 0)	count++;
	
	if (count<Answer)  Answer = count;
}

void make_dup(){
	for (int u = 0; u < H; u++)		//storing in duplicate array
	for (int v = 0; v < W; v++)
		cmap[u][v] = map[u][v];
}

void restore_orig()
{
	for (int u = 0; u < H; u++)		//restoring back
	for (int v = 0; v < W; v++)
		map[u][v] = cmap[u][v];
}

int main()
{
	int T;
	//freopen("input.txt", "r", stdin);
	scanf("%d", &T);
	for (int tc = 1; tc <= T; tc++)
	{
		Answer = 999999;
		scanf("%d %d %d", &N, &W, &H);
		for (int i = 0; i < H; i++)
		for (int j = 0; j < W; j++)
			scanf("%d", &map[i][j]);

		//permutation
		for (int i = 0; i<W; i++){
			if (N == 1){  //for one bomb
				make_dup();
				blast(i, -1, -1, -1);
				calculateRemaining();
				restore_orig();
				continue;
			}
			for (int j = 0; j<W; j++){
				if (N == 2){ //for two bombs
					make_dup();
					blast(i, j, -1, -1);
					calculateRemaining();
					restore_orig();
					continue;
				}
				for (int k = 0; k<W; k++){
					if (N == 3){	//for three bombs
						make_dup();
						blast(i, j, k, -1);
						calculateRemaining();
						restore_orig();
						continue;
					}
					for (int l = 0; l<W; l++){ //for four bombs
						make_dup();
						blast(i, j, k, l);
						calculateRemaining();
						restore_orig();
						continue;
					}
				}
			}
		}
		printf("#%d %d\n", tc, Answer);
	}
	return 0;
}