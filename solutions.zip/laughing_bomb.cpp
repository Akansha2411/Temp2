#include<iostream>

using namespace std;
int mat[100][100];
int vis[100][100];
int n,m;

void func(int x,int y,int n,int m,int a)
{
    
    int q[100000]={0};
    int front=0,rear=0;
    int u;
    u=(x*a)+y;
    q[rear]=u;
    rear++;
    while(front!=rear)
    {
               /* for(int i=1;i<=n;i++)
            {for(int j=1;j<=m;j++)
                cout<<vis[i][j]<<"  ";
            cout<<endl;} 
            cout<<endl<<endl;*/
        int v=q[front];
        front++;
        x=v/a;
        y=v%a;
        if(x>1 && !vis[x-1][y] && mat[x-1][y]==1)
        {
            /*if(x-1==9&&y==1)
                cout<<"U"<<endl;*/
            vis[x-1][y]=vis[x][y]+1;
            u=(x-1)*a+y;
            q[rear]=u;
            rear++;
        }
        if(x<n && !vis[x+1][y] && mat[x+1][y]==1)
        {
            /*if(x+1==9&&y==1)
                cout<<"D"<<endl;*/
            vis[x+1][y]=vis[x][y]+1;
            u=(x+1)*a+y;
            q[rear]=u;
            rear++;
        }
        if(y>1 && !vis[x][y-1] && mat[x][y-1]==1)
        {
            /*if(x==9&&y-1==1)
                cout<<"L"<<endl;*/
            vis[x][y-1]=vis[x][y]+1;
           /* if(x==10&&y==3)
                cout<<vis[x][y]<<" YO! "<<vis[x][y-1]<<endl;*/
            u=x*a+y-1;
            q[rear]=u;
            rear++;
        }
        if(y<m && !vis[x][y+1] && mat[x][y+1]==1)
        {
            /*if(x==9&&y+1==1)
                cout<<"R"<<endl;*/
            vis[x][y+1]=vis[x][y]+1;
            u=x*a+y+1;
            q[rear]=u;
            rear++;
        }
    }
}
int main()
{
    int t;
    cin>>t;
    int c=0;
    while(t--)
    {
        int x,y,max=0;
        cin>>n>>m;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++)
                cin>>mat[i][j];
        
        cin>>x>>y;
        
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++)
                vis[i][j]=0;
                
        vis[x][y]=1;
         
        /*for(int i=1;i<=n;i++)
            {for(int j=1;j<=m;j++)
                cout<<vis[i][j];
            cout<<endl;}   
        cout<<endl;*/   
        
        int v;
        if(n>m)
            v=n;
        else
            v=m;
            
        func(x,y,n,m,v+1);
        
        /*for(int i=1;i<=n;i++)
            {for(int j=1;j<=m;j++)
                cout<<vis[i][j]<<"  ";
            cout<<endl;}  */ 
            
        for(int i=1;i<=n;i++)
            for(int j=1;j<n;j++)
                {
                    if(vis[i][j]>max)
                        max=vis[i][j];
                }
        c++;
        cout<<"#"<<c<<" "<<max<<endl;
    }
}