#include<iostream>
using namespace std;

void sort(int arr[],int n)
{
    int i, j, id;
    for (i = 0; i < n-1; i++)
    {
        id = i;
        for (j = i+1; j < n; j++)
            if (arr[j] < arr[id])
                id = j;
        swap(arr[id], arr[i]);
    }
}
int func(int t1[],int t2[],int a,int b)
{
	int d=INT_MAX;
	int m=max(a,b);
	int ox[m];
	for(int i=0,j=0,k=0;i<a,j<b;)
	{
		if(t1[i]==t2[j])
			return 0;
		/*if(i==a-1&&j!=b-1)
		{
			
		}*/
		
		if(t1[i]>t2[j])
		{	
			d=abs(t1[i]-t2[j]);
			if(k!=0&&ox[k-1]>d)
				ox[k]=d;
			else if(k==0)
				ox[k]=d;
			k++;
			if(j+1!=b)
				j++;
		}
		else if(t1[i]<t2[j])
		{
			d=abs(t1[i]-t2[j]);
			if(k!=0&&ox[k-1]>d)
				ox[k]=d;
			else if(k==0)
				ox[k]=d;
			k++;
			if(i+1!=a)
				i++;
		}	
	}
		return; 
}
main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int a,b;
		cin>>a>>b;
		int t1[a];
		int t2[b];
		for(int i=0;i<a;i++)
			cin>>t1[i];
		for(int i=0;i<b;i++)
			cin>>t2[i];
		sort(t1,a);
		sort(t2,b);
		int s=func(t1,t2,a,b);
		cout<<s<<endl;
	}
}