#include<iostream>
using namespace std;

int mat[10][10];
bool vis[10][10];

void func(int n,int i,int j,int b,int sum,int &max)
{
	if(b==0)
	{
		if(sum>max)
			max=sum;
		return;
	}
	
	if(i<0||i>=n||j<0||j>=n)
		return;
	
	if(i<n-1 && !vis[i+1][j])              //down
	{
		if(mat[i+1][j]==0)
		{	vis[i+1][j]=1;
			func(n,i+1,j,b,sum,max);
			vis[i+1][j]=0;
		}
		else if(mat[i+1][j]==1 && b>0)
		{
			mat[i+1][j]=0;
			vis[i+1][j]=1;
			func(n,i+1,j,b-1,sum,max);
			mat[i+1][j]=1;
			vis[i+1][j]=0;
		}
		else if(mat[i+1][j]>1)
		{
			sum+=mat[i+1][j];
			vis[i+1][j]=1;
			func(n,i+1,j,b,sum+=mat[i+1][j],max);
			//vis[i+1][j]=0;
		}
	}
	if(i>0 && !vis[i-1][j])            //up
	{
		if(mat[i-1][j]==0)
		{	vis[i-1][j]=1;
			func(n,i-1,j,b,sum,max);
			vis[i-1][j]=0;
		}
		else if(mat[i-1][j]==1 && b>0)
		{
			mat[i-1][j]=0;
			vis[i-1][j]=1;
			func(n,i-1,j,b-1,sum,max);
			mat[i-1][j]=1;
			vis[i-1][j]=0;
		}
		else if(mat[i-1][j]>1)
		{
			sum+=mat[i-1][j];
			vis[i-1][j]=1;
			func(n,i-1,j,b,sum+=mat[i-1][j],max);
			//vis[i-1][j]=0;
		}
	}
	if(j<n-1 && !vis[i][j+1])      //right
	{
		if(mat[i][j+1]==0)
		{	vis[i][j+1]=1;
			func(n,i,j+1,b,sum,max);
			vis[i][j+1]=0;
		}
		else if(mat[i][j+1]==1 && b>0)
		{
			mat[i][j+1]=0;
			vis[i][j+1]=1;
			func(n,i,j+1,b-1,sum,max);
			mat[i][j+1]=1;
			vis[i][j+1]=0;
		}
		else if(mat[i][j+1]>1)
		{
			sum+=mat[i][j+1];
			vis[i][j+1]=1;
			func(n,i,j+1,b,sum+=mat[i][j+1],max);
			//vis[i][j+1]=0;
		}
	}
	if(j>0 && !vis[i][j-1])          //left
	{
		if(mat[i][j-1]==0)
		{	vis[i][j-1]=1;
			func(n,i,j-1,b,sum,max);
			vis[i][j-1]=0;
		}
		else if(mat[i][j-1]==1 && b>0)
		{
			mat[i][j-1]=0;
			vis[i][j-1]=1;
			func(n,i,j-1,b-1,sum,max);
			mat[i][j-1]=1;
			vis[i][j-1]=0;
		}
		else if(mat[i][j-1]>1 )
		{
			sum+=mat[i][j-1];
			vis[i][j-1]=1;
			func(n,i,j-1,b,sum+=mat[i][j-1],max);
			//vis[i][j-1]=0;
		}
	}
	return;
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n,x,y,b=3,sum=0,max=0;
		cin>>n;
		for(int i=0;i<n;i++)
			for(int j=0;j<n;j++)
				{
					cin>>mat[i][j];
					if(mat[i][j]==2)
					{
						x=i;
						y=j;
					}	
				}
				
		for(int i=0;i<n;i++)
			for(int j=0;j<n;j++)
				vis[i][j]=0;
			
		vis[x][y]=1;
		
		func(n,x,y,b,sum,max);
		cout<<max<<endl;
	}	
}	