#include<iostream>
using namespace std;
int mat[21][21];
bool vis[21][21];
int ans[21][21];

void func(int i, int j, int x, int y, int n, int c, int &max)
{
	if(i == x && j == y)
	{
		if(c > max)
		{
			max = c;
			for(int k = 0; k < n;k++)
			    for(int l = 0; l < n; l++)
				    ans[k][l] = mat[k][l];
		}
		return;
	}

	if(i < 0 || i == n || j < 0 || j == n)
		return;

	if(i > 0 && mat[i - 1][j] != 1 && mat[i - 1][j] != 3 && vis[i - 1][j] != 1)
	{
		vis[i - 1][j] = 1;
		if(mat[i - 1][j] == 2)
			{
			    mat[i-1][j]=3;
			    func(i-1,j,x,y,n,c+1,max);
			    mat[i-1][j]=2;
			}   
		else
		{
			mat[i - 1][j] = 3;
			func(i - 1, j, x, y, n, c, max);
			mat[i - 1][j] = 0;
		}
		vis[i - 1][j] = 0;
	}
	if(i < n-1 && mat[i + 1][j] != 1 && mat[i + 1][j] != 3 && vis[i + 1][j] != 1)
	{
		vis[i + 1][j] = 1;
		if(mat[i + 1][j] == 2)
		{
		    mat[i+1][j]=3;
			func(i + 1, j, x, y, n, c + 1, max);
			mat[i+1][j]=2;
		}	
		else
		{
			mat[i + 1][j] = 3;
			func(i + 1, j, x, y, n, c, max);
			mat[i + 1][j] = 0;
		}
		vis[i + 1][j] = 0;
	}
	if(j > 0 && mat[i][j-1] != 1 && mat[i][j-1] != 3 && vis[i][j-1] != 1)
	{
		vis[i][j-1] = 1;
		if(mat[i][j-1] == 2)
		{
		    mat[i][j-1]=3;
			func(i, j-1, x, y, n, c + 1, max);
			mat[i][j-1]=2;
		}	
		else
		{
			mat[i][j - 1] = 3;
			func(i, j - 1, x, y, n, c, max);
			mat[i][j - 1] = 0;
		}
		vis[i][j-1] = 0;
	}
	if(j < n-1 && mat[i][j + 1] != 1 && mat[i][j+1] != 3 && vis[i][j + 1] != 1)
	{
		vis[i][j + 1] = 1;
		if(mat[i][j + 1] == 2)
		{
		    mat[i][j+1]=3;
		    func(i, j + 1, x, y, n, c + 1, max);
		    mat[i][j+1]=2;
		}    
		else
		{
			mat[i][j + 1] = 3;
			func(i, j + 1, x, y, n, c, max);
			mat[i][j + 1] = 0;
		}
		vis[i][j + 1] = 0;
	}
}
int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		for(int i = 0; i < n; i++)
		for(int j = 0; j < n; j++)
			cin >> mat[i][j];
		for(int i = 0; i < n; i++)
		for(int j = 0; j < n; j++)
			vis[i][j] = 0;
		int max = 0;
		vis[0][0] = 1;
		mat[0][0] = 3;
		func(0,0,n-1,n-1,n,0,max);
		for(int k = 0; k < n; k++)
		{
			for(int l = 0; l < n; l++)
				cout << ans[k][l] << " ";
			cout << endl;
		}
		cout << max<<endl;
	}
	return 0;
}