#include<iostream>
using namespace std;

void sort(int arr[],int n)
{
    int i, j, id;
    for (i = 0; i < n-1; i++)
    {
        id = i;
        for (j = i+1; j < n; j++)
            if (arr[j] < arr[id])
                id = j;
        swap(arr[id], arr[i]);
    }
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		
	}
}