#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INF 0x1EFFFF
#define MAX_INDEX 10000
#define MAX 100
#define MIN(a,b)   (a < b ? a : b)

int a[MAX], last;
char v[MAX_INDEX];
int n, k;
int dp[MAX_INDEX];

int cmpfunc(const void * a, const void * b)
{
	return (*(int*)a - *(int*)b);
}

int find_solution(int index)
{
	if (index > last)
		return 0;

	if (dp[index])
		return dp[index];

	int road = a[v[index]];
	int i, cur_cost, cost = INF;
	//printf("For index %d, road to repair is %d\n", index, road);

	for (i = road - k + 1; i <= road; i++)
	{
		if (index > i)
			cur_cost = k - (index - i);
		else
			cur_cost = k;

		cost = MIN(cost, cur_cost + find_solution(i + k));
	}

	dp[index] = cost;
	return cost;
}

int main()
{
	int i, j, T, test;
	unsigned short b[MAX];

	//freopen("Test.txt", "r", stdin);
	scanf("%d", &T);
	for (test = 1; test <= T; test++)
	{
		scanf("%d %d", &n, &k);
		memset(b, 0, sizeof(short)* MAX);
		memset(v, 0,  MAX_INDEX);
		memset(dp, 0, sizeof(int)* MAX_INDEX);

		for (i = 0; i < n; i++)
		{
			scanf("%d", &a[i]);
			b[a[i]] = 1;
		}

		j = 0;

		for (i = 0; i < n; i++)
		{
			while (b[j] == 0)
			{
				v[j] = i;
				j++;
			}
			v[j] = i;			
			last = j;
			j++;
		}
		v[j] = i;	

		qsort(a, n, sizeof(int), cmpfunc);

		printf("#%d %d\n", test, k + find_solution(a[0] + k));
	}
	return 0;
}