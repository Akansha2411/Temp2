#include<iostream>
using namespace std;
int mat[100][100];
bool vis[100][100];
int n,m;

struct p
{
  bool u=0,d=0,r=0,l=0;  
};

void func(int i,int j,int l,p a[8],int &c,int &res)
{
    cout<<"L "<<l<<endl; 
    cout<<"c "<<c<<endl;
    if(l==0)
    {
        //cout<<"yes c "<<c<<endl;
        if(c>res)
            res=c;
        return;
    }
    cout<<i<<" "<<j<<endl;
    
    for(int x=0;x<m;x++)
        {for(int k=0;k<n;k++)
            cout<<vis[x][k];
        cout<<endl;
        }
    if(i>=m||i<0||j>=n||j<0)
        return;
        
    if(!vis[i+1][j] && l>0 && a[mat[i][j]].d && a[mat[i+1][j]].u )
    {
       // cout<<"d"<<endl;
        vis[i+1][j]=1;
        c++;
        func(i+1,j,l-1,a,c,res);
        //vis[i+1][j]=0;
    }

    if(!vis[i-1][j] && l>0 && a[mat[i][j]].u && a[mat[i-1][j]].d )
    {
       // cout<<"u"<<endl;
        vis[i-1][j]=1;
        c++;
        func(i-1,j,l-1,a,c,res);
        //vis[i-1][j]=0;
    }
    
    if(!vis[i][j+1] && l>0 && a[mat[i][j]].r && a[mat[i][j+1]].l )
    {
        //cout<<"r"<<endl;
        vis[i][j+1]=1;
        c++;
        func(i,j+1,l-1,a,c,res);
        //vis[i][j+1]=0;
    }
    
    if(!vis[i][j-1] && l>0 && a[mat[i][j]].l && a[mat[i][j-1]].r )
    {
       // cout<<"l"<<endl;
        vis[i][j-1]=1;
        c++;
        func(i,j-1,l-1,a,c,res);
        //vis[i][j-1]=0;
    }
    if(c>res)
      res=c;
}
int main()
{
    p a[8];
    
    a[1].u=1;
    a[1].d=1;
    a[1].l=1;
    a[1].r=1;
    a[2].u=1;
    a[2].d=1;
    a[3].r=1;
    a[3].l=1;
    a[4].u=1;
    a[4].r=1;
    a[5].d=1;
    a[5].r=1;
    a[6].l=1;
    a[6].d=1;
    a[7].u=1;
    a[7].l=1;
    
    int t;
    cin>>t;
    while(t--)
    {
        int x,y,l;
        cin>>m>>n>>x>>y>>l;
        l=l-1;
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++)
                cin>>mat[i][j];
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++)
                vis[i][j]=0;        
        int res=0;
        int c=1;
        vis[x][y]=1;
        if(mat[x][y]==0)
            cout<<res<<endl;
        else    
          {
              func(x,y,l,a,c,res);
              cout<<res<<endl;
          }  
    }
    return 0;
}