#include<iostream>
using namespace std;
int mat[51][51];
int vis[51][51] ;
int m, n, k;

struct p{
	bool u=0, d=0, r=0, l=0;
};

void func(int i,int j,int a,p arr[8],int &count)
{
	int q[3000] = {0};
	int r = 0, f = 0;
	if(mat[i][j]==0)
	    return;
	    
	int v = i*a + j;count++;
	q[r] = v;
	r++;
	while(f != r)
	{
		int v = q[f];
		f++;
		i = v / a;
		j = v%a;
		
		if(arr[mat[i][j]].u && arr[mat[i - 1][j]].d && !vis[i - 1][j] && vis[i][j] != k)
		{
			count++;
			vis[i - 1][j] = vis[i][j] + 1;
			v = (i - 1)*a + j;
			q[r] = v;
			r++;
		}
		if(arr[mat[i][j]].d && arr[mat[i + 1][j]].u && !vis[i + 1][j] && vis[i][j] != k )
		{
			count++;
			vis[i + 1][j] = vis[i][j] + 1;
			v = (i + 1)*a + j;
			q[r] = v;
			r++;
		}
		if(arr[mat[i][j]].l && arr[mat[i][j - 1]].r && !vis[i][j - 1] && vis[i][j] != k )
		{
			count++;
			vis[i][j - 1] = vis[i][j] + 1;
			v = i*a + j-1;
			q[r] = v;
			r++;
		}
		if(arr[mat[i][j]].r && arr[mat[i][j + 1]].l && !vis[i][j + 1] && vis[i][j] != k )
		{
			count++;
			vis[i][j + 1] = vis[i][j] + 1;
			v = i*a + j+1;
			q[r] = v;
			r++;
		}
	}
}

int main()
{
	p arr[8];
	arr[1].u = 1;
	arr[1].d = 1;
	arr[1].l = 1;
	arr[1].r = 1;
	arr[2].u = 1;
	arr[2].d = 1;
	arr[3].l = 1;
	arr[3].r = 1;
	arr[4].u = 1;
	arr[4].r = 1;
	arr[5].d = 1;
	arr[5].r = 1;
	arr[6].l = 1;
	arr[6].d = 1;
	arr[7].u = 1;
	arr[7].l = 1;
	int t;
	cin >> t;
	while(t--)
	{
		int x, y;
		cin >> m >> n >> x >> y >> k;
		for(int i = 0; i < m;i++)
		for(int j = 0; j < n; j++)
		{
		    vis[i][j]=0;
		    cin >> mat[i][j] ;
		}    
		vis[x][y] = 1;
		int count = 0;
		int g=m;
		if(n>m)
			g = n;
		func(x, y,g+1,arr,count);
		cout << count << endl;
	}
}