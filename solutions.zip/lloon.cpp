#include<iostream>
using namespace std;
void cpy(int a[],int arr[],int n,int v)
{
    for(int j=0,k=0;j<n;j++)
    {
        if(a[j]==v)
            continue;
        else
        {
            arr[k]=a[j];
            k++;
        }
    }
}
void func(int a[],int &msum,int n,int sum,int v)
{
    if(n==1)
    {
        sum+=a[0];
        if(msum<sum)
            msum=sum;
        return;
    }
 for(int j=0;j<n;j++)
 { 
    v=a[j];
    if(n==1)
    {
      sum+=a[j];
    }
    else if(j==0&&n>1)
    {
        int arr[n-1];
        cpy(a,arr,n,v);
        func(arr,msum,n-1,sum+a[j+1],v);
    }
    else if(j==n-1&&n>1)
    {
        int arr[n-1];
        cpy(a,arr,n,v);
        func(arr,msum,n-1,sum+a[j-1],v);
    }
    else
    {
        int arr[n-1];
        cpy(a,arr,n,v);
        func(arr,msum,n-1,sum+(a[j-1]*a[j+1]),v);
    }
    }
}
int main()
{   
    int t;
    cin>>t;
 while(t--)
 {
  int n;
  cin>>n;
  int a[n];
  for(int i=0;i<n;i++)
   cin>>a[i];
  int msum=0;
  int sum=0;
  func(a,msum,n,sum,0);
  if(msum<sum)
   msum=sum;
  cout<<msum<<endl;
 }
}