#include<iostream>
using namespace std;
#define D 1000
#define MAX 100

void func(int r,int c,int mat[][100],int i,int j,int v,int &minsum)
{
	if(i==r-1 && j==c-1)
	{
	    v+=mat[r-1][c-1];
		if((abs(v)+1) < minsum)
			minsum=abs(v)+1;
		return;
	}
	if(j<c)
	    func(r,c,mat,i,j+1,v+mat[i][j],minsum);
	if(i<r)   
	    func(r,c,mat,i+1,j,v+mat[i][j],minsum);
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int r,c;
		int v=0;
		int minsum=D;
		cin>>r>>c;
		int mat[r][100];
		for(int i=0;i<r;i++)
			for(int j=0;j<c;j++)
				cin>>mat[i][j];
		func(r,c,mat,0,0,v,minsum);
		cout<<minsum<<endl;	
	}		
}