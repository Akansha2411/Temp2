#include<iostream>
using namespace std;

void func()
{
	
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n,s=0,max=0;
		cin>>n;
		//int g1,g2,g3;
		int pos[3];
		int men[3];
		for(int i=0;i<3;i++)
			cin>>pos[i];
		for(int i=0;i<3;i++)
			cin>>men[i];
		func(pos,0,s,max);
		cout<<max<<endl;
	}
	return 0;
}	