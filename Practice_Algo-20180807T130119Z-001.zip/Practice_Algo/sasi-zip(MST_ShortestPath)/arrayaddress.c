#include <stdio.h>

int arr[]={1,2,3,4,5,6,7,8,9};

Myfunc(int a[])
{
	printf("Myfunc(): a=%ld    &a   =%ld    a[1]=%ld\n", a, &a, a[1]);
	printf("Myfunc(): arr=%ld  &addr=%ld, arr[1]=%d \n", arr, &arr, arr[1]);
	a[1]=99;printf("\n");
	printf("Myfunc(): a=%ld    &a   =%ld    a[1]=%ld\n", a, &a, a[1]);
	printf("Myfunc(): arr=%ld  &addr=%ld, arr[1]=%d \n", arr, &arr, arr[1]);

}

main()
{
	printf("main()  : arr=%ld  &addr=%ld, arr[1]=%d \n", arr, &arr, arr[1]);
	Myfunc(arr);
	printf("main()  : arr=%ld  &addr=%ld, arr[1]=%d \n", arr, &arr, arr[1]);
	
}


